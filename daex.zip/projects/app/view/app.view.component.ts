/**
 * 场景视图组件
 * @class: ViewComponent
 * @version: 0.0.1
 * @date: 2018/04/24
 * @author: fico
 * @description:
 */
import { Component } from '@angular/core';
@Component({template: '<router-outlet></router-outlet>'})
export class ViewComponent {}
