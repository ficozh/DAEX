/**
 * 判断引用是否被定义
 * @function: isDefined
 * @version: 0.0.1
 * @date: 2018/06/01
 * @author: fico
 * @description:
 */
export function isDefined(value) {
    return typeof value !== 'undefined';
}
