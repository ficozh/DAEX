/**
 * 判断引用是否为函数
 * @function: isFunction
 * @version: 0.0.1
 * @date: 2018/06/05
 * @author: fico
 * @description:
 */
export function isFunction(value) {
    return typeof value === 'function';
}
